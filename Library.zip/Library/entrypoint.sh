#!/bin/bash
echo "Starting Backend"

if [[ -z $PROFILE ]]; then profile=-Dspring.profiles.active=dev; else profile=-Dspring.profiles.active=$PROFILE; fi;

echo "Current Profile: $profile"


java -Djava.security.egd=file:/dev/./urandom $profile -Dblabla -jar /project/target/residence-0.0.1-SNAPSHOT.jar;
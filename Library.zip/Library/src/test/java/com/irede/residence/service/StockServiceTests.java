package com.irede.residence.service;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.StockRepository;
import com.irede.residence.domain.service.BookService;
import com.irede.residence.domain.service.StockService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.StockTO;
import com.irede.residence.domain.to.StockWithoutBookTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class StockServiceTests {

    private StockService stockService;

    private BookService bookService;

    private StockRepository stockRepository;

    private Stock stock;

    private Book book;

    private UUID uuid;

    private StockTO stockTO;

    private StockWithoutBookTO stockWithoutBookTO;

    @BeforeEach
    void setUp() {
        uuid = UUID.randomUUID();
        stockRepository = mock(StockRepository.class);
        bookService = mock(BookService.class);

        stockService = new StockService(stockRepository, bookService);

        book = new Book();
        book.setId(uuid);

        stock = Stock.builder().book(book).totalQuantity(10).availableQuantity(10).build();
        stock.setId(UUID.fromString("9fa20d2b-dfba-4d76-a847-7596a9ba8f3f"));
        stockTO = StockTO.builder().bookID(book.getId()).totalQuantity(10).build();
        stockWithoutBookTO = StockWithoutBookTO.builder().totalQuantity(10).build();
    }

    private void invokeMethodWithExceptions(Method method, Object... args) {
        try {
            method.setAccessible(true);
            method.invoke(stockService, args);
        } catch (IllegalAccessException | InvocationTargetException e) {
            fail(e);
        }
    }

    @Test
    void getAllStocks() {
        List<Stock> stocks = new ArrayList<>() {{
            add(stock);
        }};
        PaginationTO pagination = new PaginationTO(0, 10);
        PageTO<Stock> page = new PageTO<>(stocks, 10);
        when(stockRepository.findAll(pagination)).thenReturn(page);

        PageTO<Stock> stocksPage = stockService.getAll(pagination);
        assertEquals(1, stocksPage.getContent().size());
        assertEquals(stocksPage.getPage(), 0);
        assertEquals(stocksPage.getTotal(), 10);
    }

    @Test
    void getStock_whenBookNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenThrow(new DomainException(ErrorCode.BOOK_NOT_FOUND));

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.getStockIfExistsByBookId(uuid);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.BOOK_NOT_FOUND);
    }

    @Test
    void getStock_whenStockNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.getStockIfExistsByBookId(uuid);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.STOCK_NOT_FOUND);
    }

    @Test
    void getStock_whenStockFound() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        when(stockRepository.findStockByBookId(uuid)).thenReturn(Optional.of(stock));

        Stock stockDB = stockService.getStockIfExistsByBookId(uuid);
        assertEquals(stockDB, stock);
    }

    @Test
    void createStock_whenItSave() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        when(stockRepository.save((Stock) Mockito.any())).thenReturn(stock);

        Stock stockSaved = stockService.addBookToStock(stockTO);
        assertEquals(stockSaved, stock);
    }

    @Test
    void createStock_whenStockExists() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        when(stockRepository.findStockByBookId(uuid)).thenReturn(Optional.ofNullable(stock));

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.addBookToStock(stockTO);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.BOOK_ALREADY_ON_STOCK);
    }

    @Test
    void createStock_whenBookNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenThrow(new DomainException(ErrorCode.BOOK_NOT_FOUND));

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.addBookToStock(stockTO);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.BOOK_NOT_FOUND);
    }

    @Test
    void updateStock_thenSaveIt() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        Stock stockUpdated = Stock.builder().book(book).totalQuantity(20).build();

        when(stockRepository.findById(uuid)).thenReturn(Optional.ofNullable(stock));
        when(stockRepository.save(stock)).thenReturn(stockUpdated);

        Stock stockResponse = stockService.updateStockTotalQuantity(stockWithoutBookTO, uuid);
        assertEquals(stockResponse.getBook(), book);
        assertEquals(stockResponse.getTotalQuantity(), 20);
    }

    @Test
    void updateStock_whenStockNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        Stock stockUpdated = Stock.builder().book(book).totalQuantity(20).build();

        when(stockRepository.findById(uuid)).thenReturn(Optional.empty());
        when(stockRepository.save(stock)).thenReturn(stockUpdated);

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.updateStockTotalQuantity(stockWithoutBookTO, stock.getId());
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.STOCK_NOT_FOUND);
    }

    @Test
    void deleteStock() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        when(stockRepository.findById(uuid)).thenReturn(Optional.ofNullable(stock));
        stockService.deleteStock(uuid);
    }

    @Test
    void deleteStock_whenStockNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        when(stockRepository.findStockByBookId(uuid)).thenReturn(Optional.empty());

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.deleteStock(uuid);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.STOCK_NOT_FOUND);
    }

    @Test
    void updateStockSituation_whenAvailable() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        Stock stock = Stock.builder().book(Book.builder().status(BookStatus.AVAILABLE).build()).build();

        try {
            Method updateStockStatusMethod = StockService.class.getDeclaredMethod("updateStockStatus",
                    Stock.class, int.class);

            invokeMethodWithExceptions(updateStockStatusMethod, stock, 1);

            assertEquals(stock.getBook().getStatus(), BookStatus.AVAILABLE);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }

    @Test
    void updateStockSituation_whenNotAvailable() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        Stock stock = Stock.builder().book(Book.builder().status(BookStatus.AVAILABLE).build()).build();

        try {
            Method updateStockStatusMethod = StockService.class.getDeclaredMethod("updateStockStatus",
                    Stock.class, int.class);

            invokeMethodWithExceptions(updateStockStatusMethod, stock, 0);

            assertEquals(stock.getBook().getStatus(), BookStatus.UNAVAILABLE);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }

    @Test
    void updateStockQuantity_whenQuantityNotPossible() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        Stock stock = Stock.builder().availableQuantity(10).totalQuantity(20).build();

        try {
            Method updateStockQuantityMethod = StockService.class.getDeclaredMethod("updateStockQuantity",
                    Stock.class, int.class);
            updateStockQuantityMethod.setAccessible(true);

            DomainException exception = assertThrows(DomainException.class, () -> {

                try {
                    updateStockQuantityMethod.invoke(stockService, stock, 5);
                } catch (InvocationTargetException e) {
                    if (e.getCause() instanceof DomainException) {
                        throw (DomainException) e.getCause();
                    } else {
                        throw new RuntimeException(e.getCause());
                    }
                }
            });

            ErrorCode errorCode = exception.getCode();
            assertEquals(errorCode, ErrorCode.DISALLOWED_AMOUNT);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }

    @Test
    void updateStockQuantity_whenQuantityPossible() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        stock.setTotalQuantity(20);

        try {
            Method updateStockQuantityMethod = StockService.class.getDeclaredMethod("updateStockQuantity",
                    Stock.class, int.class);

            invokeMethodWithExceptions(updateStockQuantityMethod, stock, 30);

            assertEquals(stock.getTotalQuantity(), 30);
            assertEquals(stock.getAvailableQuantity(), 20);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }

    @Test
    void updateAvailableQuantity_thenSaveIt() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);

        when(stockRepository.findStockByBookId(uuid)).thenReturn(Optional.ofNullable(stock));
        when(stockRepository.save(stock)).thenReturn(stock);

        Book bookResponse = stockService.updateAvailableQuantity(uuid, 10);
        bookResponse.setId(uuid);

        assertEquals(stockService.getStockIfExistsByBookId(bookResponse.getId()).getAvailableQuantity(), 20);
    }

    @Test
    void updateAvailableQuantity_whenStockNotFound() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);

        when(stockRepository.findStockByBookId(uuid)).thenReturn(Optional.empty());
        when(stockRepository.save(stock)).thenReturn(stock);

        DomainException exception = assertThrows(DomainException.class, () -> {
            stockService.updateAvailableQuantity(uuid, 10);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.STOCK_NOT_FOUND);
    }

    @Test
    void validateBookSituation_whenAvailableQuantityPossible() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);
        stock.setTotalQuantity(30);

        try {
            Method validateBookSituationMethod = StockService.class.getDeclaredMethod("validateBookSituation",
                    Stock.class, int.class);

            invokeMethodWithExceptions(validateBookSituationMethod, stock, 10);

            assertEquals(stock.getAvailableQuantity(), 20);
            assertEquals(stock.getTotalQuantity(), 30);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }

    @Test
    void validateBookSituation_whenAvailableQuantityNotPossible() throws DomainException {
        when(bookService.findById(uuid)).thenReturn(book);

        try {
            Method validateBookSituationMethod = StockService.class.getDeclaredMethod("validateBookSituation",
                    Stock.class, int.class);
            validateBookSituationMethod.setAccessible(true);

            DomainException exception = assertThrows(DomainException.class, () -> {
                try {
                    validateBookSituationMethod.invoke(stockService, stock, -11);
                } catch (InvocationTargetException e) {
                    if (e.getCause() instanceof DomainException) {
                        throw (DomainException) e.getCause();
                    } else {
                        throw new RuntimeException(e.getCause());
                    }
                }
            });

            ErrorCode errorCode = exception.getCode();
            assertEquals(errorCode, ErrorCode.DISALLOWED_AMOUNT);
        } catch (NoSuchMethodException e) {
            fail(e);
        }
    }
}
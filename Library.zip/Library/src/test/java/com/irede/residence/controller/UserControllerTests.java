package com.irede.residence.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.irede.residence.application.rest.UserController;
import com.irede.residence.domain.entity.Role;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.service.CustomUserDetailsService;
import com.irede.residence.domain.service.UserService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.UserTO;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = UserController.class, useDefaultFilters = false)
@Import(UserController.class)
public class UserControllerTests {

    @MockBean
    UserService userService;


    @MockBean
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    MockMvc mockMvc;


    private final String pathUrl = "/v1/user";

    private UUID userId;

    private User user;

    @BeforeEach
    void setUp() {
        userId = UUID.fromString("71069084-3f4f-11ed-b878-0242ac120002");
        user = User.builder().name("userTeste").email("userteste@gmail.com").phone("123456748")
                .role(Role.ADMINISTRATOR).build();


    }

    @Test
    void testGet() throws Exception {
        user.setId(userId);
        PageTO<User> pageTO = new PageTO<>(List.of(user), 1, 0, 10);
        PaginationTO paginationTO = new PaginationTO(0, 10);
        Map<String, Object> params = new HashMap<>();
        params.put("name", null);
        params.put("role", null);
        paginationTO.setParams(params);
        Mockito.when(customUserDetailsService.getUser()).thenReturn(user);
        Mockito.when(userService.getById(userId)).thenReturn(user);
        Mockito.when(userService.getAll(Mockito.any())).thenReturn(pageTO);


        //get all
        mockMvc.perform(
                        get(pathUrl).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf())).
                andExpect(status().isOk())
                .andExpect(jsonPath("$.content", Matchers.hasSize(1)))
                .andExpect(jsonPath("$.content[0].id", Matchers.is(user.getId().toString())))
                .andExpect(jsonPath("$.content[0].id", Matchers.is(user.getId().toString())));
    }

    @Test
    void testDelete() throws Exception {

        //normal delete
        mockMvc.perform(
                delete(pathUrl + "/" + userId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf())
        ).andExpect(status().isOk()).andExpect(jsonPath("$").doesNotExist());

        //check errors
        mockMvc.perform(
                        delete(pathUrl).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("TEACHER"))
                                .with(csrf()))
                .andExpect(status().isMethodNotAllowed())
                .andExpect(status().is(Matchers.not(status().isOk())));
    }

    @Test
    void testUpdate() throws Exception {

        UserTO userTO = UserTO.builder().email("userModify@gmail.com").name("userTeste").phone("12345")
                .role(Role.STUDENT).build();
        user.setId(userId);
        user.setEmail(userTO.getEmail());

        Mockito.when(userService.updateUser(userTO, userId)).thenReturn(user);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(userTO);

        //normal update
        mockMvc.perform(
                        put(pathUrl + "/" + userId).contentType(MediaType.APPLICATION_JSON).content(json)
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf())
                ).andExpect(status().isOk())
                .andExpect(jsonPath("$.email", Matchers.is(userTO.getEmail())))
                .andExpect(jsonPath("$.role", Matchers.is(Role.ADMINISTRATOR.name())));

        //errors expected
        //without body
        mockMvc.perform(put(pathUrl + "/" + userId).contentType(MediaType.APPLICATION_JSON)
                .with(user("User").roles("TEACHER"))
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());

    }

    @Test
    void testRegister() throws Exception {
        UserTO userDTO = UserTO.builder().email("userteste@gmail.com").name("userTeste")
                .role(Role.ADMINISTRATOR).phone("027.966.400-19").build();

        Mockito.when(userService.createUser(userDTO)).thenReturn(user);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(userDTO);

        mockMvc.perform(
                        post(pathUrl).contentType(MediaType.APPLICATION_JSON).content(json)
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMIN"))
                                .with(csrf())
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email", Matchers.is("userteste@gmail.com")))
                .andExpect(jsonPath("$.role", Matchers.is(Role.ADMINISTRATOR.name())));

        //check status register
        mockMvc.perform(post(pathUrl).contentType(MediaType.APPLICATION_JSON).content(json)
                        .accept(MediaType.APPLICATION_JSON).with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf()))
                .andExpect(status().isOk());

        //check  errors
        //without error
        mockMvc.perform(post(pathUrl).contentType(MediaType.APPLICATION_JSON).content(json)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf())
                )
                .andExpect(status().is(Matchers.not(status().isBadRequest())))
                .andExpect(status().is(Matchers.not(status().isNotFound())));

        //without body
        mockMvc.perform(
                        post(pathUrl).contentType(MediaType.APPLICATION_JSON).content("{}")
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf())
                )
                .andExpect(status().isBadRequest());
    }

}

package com.irede.residence.service;

import com.irede.residence.domain.entity.Role;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.UserRepository;
import com.irede.residence.domain.service.CustomUserDetailsService;
import com.irede.residence.domain.service.UserService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.UserTO;
import com.irede.residence.domain.utils.EncryptService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UserServiceTests {

    private UserService userService;

    private UserRepository userRepository;

    private EncryptService encryptService;

    private CustomUserDetailsService customUserDetailsService;

    private User administrator;

    private UserTO userTO;


    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        encryptService = mock(EncryptService.class);
        customUserDetailsService = mock(CustomUserDetailsService.class);

        userService = new UserService(userRepository, encryptService, customUserDetailsService);

        administrator = User.builder()
                .name("userTeste")
                .email("userteste@gmail.com")
                .phone("12345")
                .password("teste")
                .role(Role.ADMINISTRATOR)
                .createdAT(new Date())
                .deletedAt(new Date())
                .build();

        userTO = UserTO.builder().name("userTeste").phone("12345").email("userteste@gmail.com")
                .role(Role.ADMINISTRATOR).build();
    }

    @Test
    void getAllUsers() {
        List<User> users = new ArrayList<>(){{add(administrator);}};
        PaginationTO pagination = new PaginationTO(0, 10);
        PageTO<User> page = new PageTO<>(users, 10);
        when(userRepository.findAll(pagination)).thenReturn(page);

        Mockito.when(customUserDetailsService.getUser()).thenReturn(administrator);

        PageTO<User> usersPage = userService.getAll(pagination);
        assertEquals(1,usersPage.getContent().size());
        assertEquals(usersPage.getPage(), 0);
        assertEquals(usersPage.getTotal(), 10);
    }

    @Test
    void getUserJwt() {
        UUID uuid = UUID.randomUUID();
        when(userRepository.findById(uuid)).thenReturn(Optional.ofNullable(administrator));
        when(customUserDetailsService.getUser()).thenReturn(administrator);
        User userDB = userService.getUserJwt();
        assertEquals(administrator, userDB);
    }

    @Test
    void getUser_whenNotFound() {
        UUID uuid = UUID.randomUUID();

        DomainException exception = assertThrows(DomainException.class, () -> {
            userService.getById(uuid);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.USER_NOT_FOUND);
    }

    @Test
    void getUser_whenUserFound() throws DomainException {
        UUID uuid = UUID.randomUUID();
        when(userRepository.findById(uuid)).thenReturn(Optional.of(administrator));

        User user = userService.getById(uuid);
        assertEquals(user, administrator);
    }

    @Test
    void createUser_whenItSave() throws DomainException {
        Mockito.when(customUserDetailsService.getUser()).thenReturn(administrator);
        when(userRepository.save((User) Mockito.any())).thenReturn(administrator);
        userTO.setPassword("12345");
        userTO.setConfirmPassword("12345");
        User userSaved = userService.createUser(userTO);
        assertEquals(userSaved, administrator);
    }

    @Test
    void createUser_whenPasswordDontEqual() throws DomainException {
        Mockito.when(customUserDetailsService.getUser()).thenReturn(administrator);
        when(userRepository.save((User) Mockito.any())).thenReturn(administrator);
        userTO.setPassword("12345");
        userTO.setConfirmPassword("1234");

        DomainException exception = assertThrows(DomainException.class, () -> {
            User userSaved = userService.createUser(userTO);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.INVALID_PARAMS);
    }

    @Test
    void createUser_whenUserExist() throws DomainException {
        Mockito.when(customUserDetailsService.getUser()).thenReturn(administrator);
        Mockito.when(userRepository.findUserByEmail(userTO.getEmail())).thenReturn(Optional.of(administrator));
        when(userRepository.save((User) Mockito.any())).thenReturn(administrator);
        userTO.setPassword("12345");
        userTO.setConfirmPassword("12345");

        DomainException exception = assertThrows(DomainException.class, () -> {
            User userSaved = userService.createUser(userTO);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.EMAIL_EXISTENT);
    }

    @Test
    void updateUser_thenSaveIt() throws DomainException {
        userTO.setName("newName");
        userTO.setEmail("usernew@gmail.com");
        userTO.setRole(Role.STUDENT);
        User userUpdated = User.builder().name("newName").email("usernew@gmail.com")
                .role(Role.ADMINISTRATOR).build();
        UUID id = UUID.randomUUID();

        when(userRepository.findById(id)).thenReturn(Optional.ofNullable(administrator));
        when(userRepository.save(administrator)).thenReturn(userUpdated);

        User userResponse = userService.updateUser(userTO, id);
        assertEquals(userResponse.getName(), "newName");
        assertEquals(userResponse.getEmail(), "usernew@gmail.com");
        assertEquals(userResponse.getRole(), Role.ADMINISTRATOR);
    }

    @Test
    void updateUser_thenUser_notFound() {
        userTO.setName("newName");
        userTO.setEmail("usernew@gmail.com");
        userTO.setRole(Role.STUDENT);
        User userUpdated = User.builder().name("newName").email("usernew@gmail.com")
                .role(Role.ADMINISTRATOR).build();
        UUID id = UUID.randomUUID();

        when(userRepository.findById(id)).thenReturn(Optional.empty());
        when(userRepository.save(administrator)).thenReturn(userUpdated);

        DomainException exception = assertThrows(DomainException.class, () -> {
            User userResponse = userService.updateUser(userTO, id);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.USER_NOT_FOUND);
    }

    @Test
    void deleteUser() throws DomainException {
        UUID id = UUID.randomUUID();
        when(userRepository.findById(id)).thenReturn(Optional.ofNullable(administrator));
        userService.deleteUser(id);
    }

    @Test
    void deleteUser_notFound() throws DomainException {
        UUID id = UUID.randomUUID();
        when(userRepository.findById(id)).thenReturn(Optional.empty());
        DomainException exception = assertThrows(DomainException.class, () -> {
            userService.deleteUser(id);
        });
        ErrorCode errorCode = exception.getCode();
        assertEquals(errorCode, ErrorCode.USER_NOT_FOUND);
    }
}

package com.irede.residence.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.irede.residence.application.rest.StockController;
import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.service.BookService;
import com.irede.residence.domain.service.StockService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.StockTO;
import com.irede.residence.domain.to.StockWithoutBookTO;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = StockController.class, useDefaultFilters = false)
@Import(StockController.class)
public class StockControllerTests {

    @MockBean
    StockService stockService;

    @MockBean
    BookService bookService;

    @Autowired
    MockMvc mockMvc;

    private final String pathUrl = "/v1/stocks";

    private UUID bookId;

    private UUID stockId;

    private Book book;

    private Stock stock;

    private StockTO stockTO;

    private StockWithoutBookTO stockWithoutBookTO;

    @BeforeEach
    void setUp() {
        stockId = UUID.randomUUID();
        bookId = UUID.fromString("71669174-3f4f-11ed-b878-0242ac120002");
        book = new Book();
        book = Book.builder().build();
        book.setId(bookId);
        stock = Stock.builder().book(book).totalQuantity(10).build();
        stockTO = StockTO.builder().bookID(bookId).totalQuantity(10).build();
        stockWithoutBookTO = StockWithoutBookTO.builder().build();
    }

    @Test
    void testGet() throws Exception {
        stock.setId(bookId);
        PageTO<Stock> pageTO = new PageTO<>(List.of(stock), 1, 0, 10);
        PaginationTO paginationTO = new PaginationTO(0, 10);
        Map<String, Object> params = new HashMap<>();
        paginationTO.setParams(params);
        Mockito.when(bookService.findById(bookId)).thenReturn(book);
        Mockito.when(stockService.getStockIfExistsByBookId(stock.getId())).thenReturn(stock);
        Mockito.when(stockService.getAll(Mockito.any())).thenReturn(pageTO);

        mockMvc.perform(
                        get(pathUrl).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", Matchers.hasSize(1)))
                .andExpect(jsonPath("$.content[0].id", Matchers.is(stock.getBook().getId().toString())));
    }

    @Test
    void testDelete() throws Exception {

        mockMvc.perform(
                delete(pathUrl + "/" + bookId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf())
        ).andExpect(status().isNoContent()).andExpect(jsonPath("$").doesNotExist());

        mockMvc.perform(
                        delete(pathUrl)
                                .contentType(MediaType.APPLICATION_JSON)
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf()))
                .andExpect(status().isMethodNotAllowed())
                .andExpect(status().is(Matchers.not(status().isNoContent())));
    }

    @Test
    void testUpdate() throws Exception {

        stockTO = StockTO.builder().bookID(bookId).totalQuantity(50).build();
        stock.setId(stockId);
        stock.setTotalQuantity(stockTO.getTotalQuantity());

        Mockito.when(bookService.findById(bookId)).thenReturn(book);
        Mockito.when(stockService.updateStockTotalQuantity(stockWithoutBookTO, stockId)).thenReturn(stock);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(stockWithoutBookTO);

        mockMvc.perform(
                        put(pathUrl + "/" + stockId).contentType(MediaType.APPLICATION_JSON).content(json)
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf())
                ).andExpect(status().isOk())
                .andExpect(jsonPath("$.totalQuantity", Matchers.is(stockTO.getTotalQuantity())));

        mockMvc.perform(
                put(pathUrl + "/" + stockId).contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User"))
                        .with(csrf())
        ).andExpect(status().isBadRequest());
    }

    @Test
    void testRegister() throws Exception {

        Mockito.when(stockService.addBookToStock(stockTO)).thenReturn(stock);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(stockTO);

        mockMvc.perform(
                        post(pathUrl).contentType(MediaType.APPLICATION_JSON).content(json)
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMIN"))
                                .with(csrf())
                )
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.totalQuantity", Matchers.is(stockTO.getTotalQuantity())))
                .andExpect(jsonPath("$.book.id", Matchers.is(stock.getBook().getId().toString())));

        mockMvc.perform(post(pathUrl).contentType(MediaType.APPLICATION_JSON).content(json)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf())
                )
                .andExpect(status().is(Matchers.not(status().isBadRequest())))
                .andExpect(status().is(Matchers.not(status().isNotFound())));

        mockMvc.perform(
                        post(pathUrl).contentType(MediaType.APPLICATION_JSON).content("{}")
                                .accept(MediaType.APPLICATION_JSON)
                                .with(user("User").roles("ADMINISTRATOR"))
                                .with(csrf())
                )
                .andExpect(status().isBadRequest());
    }

    @Test
    void testFindByBookId() throws Exception {

        Mockito.when(bookService.findById(bookId)).thenReturn(book);
        Mockito.when(stockService.getStockIfExistsByBookId(bookId)).thenReturn(stock);

        mockMvc.perform(
                get(pathUrl + "/" + bookId).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalQuantity", Matchers.is(stockTO.getTotalQuantity())))
                .andExpect(jsonPath("$.book.id", Matchers.is(stock.getBook().getId().toString())));

        mockMvc.perform(post(pathUrl).contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .with(user("User").roles("ADMINISTRATOR"))
                        .with(csrf())
                )
                .andExpect(status().is(Matchers.not(status().isBadRequest())))
                .andExpect(status().is(Matchers.not(status().isNotFound())));
    }

}
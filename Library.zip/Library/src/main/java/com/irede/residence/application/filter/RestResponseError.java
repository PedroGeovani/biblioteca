package com.irede.residence.application.filter;

import com.irede.residence.application.response.RestError;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class RestResponseError {

    private String code;

    private String message;

    private List<RestError> restErrors;

    public RestResponseError(String code) {
        this.code = code;
        this.message = "Error Code: " + code;
        this.restErrors = new ArrayList<>();
    }

    public void addError(RestError restError) {
        restErrors.add(restError);
    }
}

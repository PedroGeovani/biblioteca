package com.irede.residence.domain.entity;

public enum Role {
    ADMINISTRATOR,
    STUDENT,
}

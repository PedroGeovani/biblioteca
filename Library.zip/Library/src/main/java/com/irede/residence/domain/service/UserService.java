package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.UserRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.UserTO;
import com.irede.residence.domain.utils.EncryptService;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

public class UserService {

    private final UserRepository userRepository;

    private final EncryptService encryptService;

    private final CustomUserDetailsService customUserDetailsService;

    public UserService(UserRepository userRepository, EncryptService encryptService,
                       CustomUserDetailsService customUserDetailsService) {
        this.userRepository = userRepository;
        this.encryptService = encryptService;
        this.customUserDetailsService = customUserDetailsService;
    }

    public PageTO<User> getAll(PaginationTO paginationTO) {
        return userRepository.findAll(paginationTO);
    }

    public User getById(UUID id) throws DomainException {
        Optional<User> user = userRepository.findById(id);
        if(user.isEmpty()){
            throw new DomainException(ErrorCode.USER_NOT_FOUND);
        }
        return user.get();
    }

    public User getUserJwt(){
        return customUserDetailsService.getUser();
    }

    public User createUser(UserTO userTO) throws DomainException {

        Optional<User> userDB = userRepository.findUserByEmail(userTO.getEmail());
        if (userDB.isPresent()) {
            throw new DomainException(ErrorCode.EMAIL_EXISTENT);
        }

        if (!userTO.getPassword().equals(userTO.getConfirmPassword())) {
            throw new DomainException("Password don't equals", ErrorCode.INVALID_PARAMS);
        }

        User user = User.builder().name(userTO.getName()).email(userTO.getEmail()).phone(userTO.getPhone())
                .role(userTO.getRole()).build();
        user.setPassword(encryptService.encryptPassword(userTO.getPassword()));
        return userRepository.save(user);
    }

    public User updateUser(UserTO userTO, UUID id) throws DomainException {

        User user = this.getById(id);

        user.setName(userTO.getName());
        user.setRole(userTO.getRole());
        user.setEmail(userTO.getEmail());
        user.setPhone(userTO.getPhone());

        return userRepository.save(user);
    }

    public void deleteUser(UUID id) throws DomainException {

        User user = this.getById(id);

        user.setDeletedAt(new Date());
        user.setUpdatedAt(new Date());
        userRepository.save(user);
    }
}

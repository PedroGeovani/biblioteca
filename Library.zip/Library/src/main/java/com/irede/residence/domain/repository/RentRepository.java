package com.irede.residence.domain.repository;

import com.irede.residence.domain.entity.Rent;

import java.util.List;
import java.util.UUID;

public interface RentRepository extends BaseRepository<Rent> {
    List<Rent> findAllActiveRentsByUserId(UUID userId);
    List<Rent> findAllActiveRentsByBookId(UUID bookId);
}

package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.StockService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.StockTO;
import com.irede.residence.domain.to.StockWithoutBookTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping(value = "/v1/stocks")
@RestController
public class StockController {
    private final StockService stockService;

    public StockController(StockService stockService) {
        this.stockService = stockService;
    }

    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<Stock>> getAll(
            @RequestParam(name = "status", required = false) BookStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        params.put("status", status);
        paginationTO.setParams(params);

        return ResponseEntity.ok(stockService.getAll(paginationTO));
    }

    @GetMapping(value = "/{bookId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> findByBookId(@PathVariable("bookId") UUID id) throws DomainException {
        return ResponseEntity.ok(stockService.getStockIfExistsByBookId(id));
    }

    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Stock> addBookToStock(@Valid @RequestBody StockTO stockTO) throws DomainException {
        return new ResponseEntity<Stock>(stockService.addBookToStock(stockTO), HttpStatus.CREATED);
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Stock> update(@Valid @RequestBody StockWithoutBookTO stockWithoutBookTO, @PathVariable("id") UUID id) throws DomainException {
        return ResponseEntity.ok(stockService.updateStockTotalQuantity(stockWithoutBookTO, id));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Stock> deleteStock(@Valid @RequestBody @PathVariable("id") UUID id) throws DomainException {
        stockService.deleteStock(id);
        return ResponseEntity.noContent().build();
    }
}

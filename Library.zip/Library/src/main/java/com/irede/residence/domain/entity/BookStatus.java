package com.irede.residence.domain.entity;

public enum BookStatus {
    AVAILABLE,
    LOANED,
    UNAVAILABLE
}

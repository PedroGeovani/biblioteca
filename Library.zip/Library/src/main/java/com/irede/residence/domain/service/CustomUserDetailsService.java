package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.User;

import java.util.UUID;

public interface CustomUserDetailsService {

    UUID getIdUserDetails();

    User getUser();

    Boolean isAuthenticated();
}

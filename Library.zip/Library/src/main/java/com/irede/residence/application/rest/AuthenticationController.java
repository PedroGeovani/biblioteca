package com.irede.residence.application.rest;

import com.irede.residence.application.request.AuthenticationRequest;
import com.irede.residence.application.response.AuthenticationResponse;
import com.irede.residence.domain.service.AuthenticationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/v1")
public class AuthenticationController {

    private final AuthenticationService authenticationService;

    public AuthenticationController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @PostMapping(value = "/authenticate")
    public ResponseEntity<AuthenticationResponse> createAuthenticationToken(
            @RequestBody AuthenticationRequest authenticationRequest) throws Exception {
        AuthenticationResponse authResponse = authenticationService
                .getAuthenticationResponse(authenticationRequest);
        return ResponseEntity.ok(authResponse);
    }
}

package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.Reserve;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.repository.ReserveRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import java.util.*;

@Component
public class PostgresReserveRepository implements ReserveRepository {

    private final SpringDataReserveRepository reserveRepository;

    public PostgresReserveRepository(SpringDataReserveRepository reserveRepository) {this.reserveRepository = reserveRepository;}

    @Override
    public PageTO<Reserve> findAll(PaginationTO paginationTO) {
        Pageable pageable = PageRequest.of(paginationTO.getPage(), paginationTO.getSize());
        Page<Reserve> reserves = reserveRepository.findAll(getAllReserves(paginationTO.getParams()),pageable);
        return new PageTO<>(reserves.getContent(), reserves.getTotalElements(), reserves.getNumber(),
                reserves.getSize());
    }

    private Specification<Reserve> getAllReserves(Map<String, Object> params) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(params.containsKey("id") && params.get("id") != null){
                Join<Reserve, User> userJoin = root.join("user");
                predicates.add(cb.equal(userJoin.get("id"), params.get("id")));
            }

            if (params.containsKey("status") && params.get("status") != null) {
                predicates.add(cb.equal(root.get("status"), params.get("status")));
            }

            if (params.containsKey("dateReserveAvailable") && params.get("dateReserveAvailable") != null) {
                Date dateReserveAvailable = (Date) params.get("dateReserveAvailable");
                predicates.add(cb.lessThanOrEqualTo(root.get("dateReserveAvailable"), dateReserveAvailable));
            }

            return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }

    @Override
    public Reserve save(Reserve entity){return reserveRepository.save(entity);}

    @Override
    public Optional<Reserve> findById(UUID id) {return reserveRepository.findById(id);}

    @Override
    public List<Optional<Reserve>> findReserveByBookTitle(String bookTitle) {return reserveRepository.findReserveByBookTitle(bookTitle);}

    @Override
    public Integer verifyLimitReserves(UUID userId) {return reserveRepository.countReservesByUserId(userId);}

    @Override
    public List<Optional<Reserve>> findReserveByUserId(UUID userId) {return reserveRepository.findReserveByUserId(userId);}

    @Override
    public void delete(Reserve reserve) {reserveRepository.delete(reserve);}
}

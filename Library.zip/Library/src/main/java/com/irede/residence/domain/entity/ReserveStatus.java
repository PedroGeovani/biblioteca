package com.irede.residence.domain.entity;

public enum ReserveStatus {
    AVAILABLE,
    UNAVAILABLE
}

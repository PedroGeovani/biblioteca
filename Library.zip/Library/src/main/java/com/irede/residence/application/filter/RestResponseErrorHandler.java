package com.irede.residence.application.filter;

import com.irede.residence.application.response.ResponseError;
import com.irede.residence.application.response.RestError;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.List;

@RestControllerAdvice
public class RestResponseErrorHandler {


    Logger logger = LogManager.getLogger(RestResponseErrorHandler.class);

    private final MessageSource messageSource;

    public RestResponseErrorHandler(MessageSource messageSource) {
        this.messageSource = messageSource;
    }


    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public RestResponseError handle(MethodArgumentNotValidException exception) {
        logger.error(exception.getMessage());

        RestResponseError err = new RestResponseError(ErrorCode.INVALID_PARAMS.name());
        List<FieldError> fieldErrors = exception.getBindingResult().getFieldErrors();

        fieldErrors.forEach(e -> {
            String message = messageSource.getMessage(e, LocaleContextHolder.getLocale());
            err.addError(new RestError(e.getField(), message));
        });

        return err;
    }

    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public RestResponseError handle(HttpMessageNotReadableException exception) {
        logger.error(exception.getMessage());
        return new RestResponseError(ErrorCode.INVALID_PARAMS.name());
    }

    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public RestResponseError handleTypeMismatch(MethodArgumentTypeMismatchException exception) {
        logger.error(exception.getMessage());
        RestResponseError err = new RestResponseError(ErrorCode.INVALID_PARAMS.name());
        String message = "Invalid type, required: " + exception.getRequiredType();
        err.addError(new RestError(exception.getName(), message));
        return err;
    }

    @ExceptionHandler(value = {DomainException.class})
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseError domainException(DomainException ex) {
        logger.error(ex.getMessage());

        Throwable cause = ex.getCause();
        if (cause != null) {
            logger.error(cause);
        }

        return new ResponseError(ex.getCode().toString(), ex.getMessage());
    }

    @ExceptionHandler(value = {AccessDeniedException.class})
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public String accessDeniedExceptionHandler(AccessDeniedException accessDeniedException) {
        return "ACCESS_DENIED";
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String internalServerError(Exception ex) {
        logger.error(ex.getMessage());
        ex.printStackTrace();
        return "Internal error";
    }

    @ExceptionHandler(value = BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public String badCredentials(BadCredentialsException ex) {
        logger.error(ex.getMessage());
        return "INVALID_CREDENTIALS";
    }
}


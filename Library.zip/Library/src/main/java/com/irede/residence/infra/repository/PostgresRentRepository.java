package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.Rent;
import com.irede.residence.domain.entity.RentStatus;
import com.irede.residence.domain.repository.RentRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class PostgresRentRepository implements RentRepository {

    private final SpringDataRentRepository rentRepository;

    public PostgresRentRepository(SpringDataRentRepository rentRepository) {
        this.rentRepository = rentRepository;
    }


    @Override
    public PageTO<Rent> findAll(PaginationTO paginationTO) {
        Pageable pageable = PageRequest.of(paginationTO.getPage(), paginationTO.getSize());
        Page<Rent> rents = rentRepository.findAll(getAllRents(paginationTO.getParams()), pageable);
        return new PageTO<>(
                rents.getContent(), rents.getTotalElements(), rents.getNumber(), rents.getSize()
        );
    }

    public Specification<Rent> getAllRents(Map<String, Object> params) {
        return (root, query, cb) -> {
            List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();

            predicates.add(cb.isNull(root.get("deletedAt")));

            if (params.containsKey("status") && params.get("status") != null) {
                predicates.add(cb.equal(root.get("status"), params.get("status")));
            }

            if (params.containsKey("rentFinalDate") && params.get("rentFinalDate") != null) {
                Date rentFinalDate = (Date) params.get("rentFinalDate");
                predicates.add(cb.lessThanOrEqualTo(root.get("rentFinalDate"), rentFinalDate));
            }

            return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }

    @Override
    public Rent save(Rent entity) {
        return rentRepository.save(entity);
    }

    @Override
    public Optional<Rent> findById(UUID id) {
        return rentRepository.findByIdAndDeletedAtIsNull(id);
    }

    @Override
    public List<Rent> findAllActiveRentsByUserId(UUID userId) {
        return rentRepository.findAllByUserIdAndStatusAndDeletedAtIsNull(
                userId, RentStatus.ACTIVE
        );
    }

    @Override
    public List<Rent> findAllActiveRentsByBookId(UUID bookId) {
        return rentRepository.findAllByBookIdAndStatusAndDeletedAtIsNull(
                bookId, RentStatus.ACTIVE
        );
    }

}

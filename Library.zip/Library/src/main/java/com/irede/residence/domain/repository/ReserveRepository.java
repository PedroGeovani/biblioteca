package com.irede.residence.domain.repository;

import com.irede.residence.domain.entity.Reserve;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ReserveRepository extends BaseRepository<Reserve> {
    Integer verifyLimitReserves(UUID userId);
    List<Optional<Reserve>> findReserveByBookTitle(String bookTitle);
    List<Optional<Reserve>> findReserveByUserId(UUID userId);
    void delete(Reserve reserve);
}

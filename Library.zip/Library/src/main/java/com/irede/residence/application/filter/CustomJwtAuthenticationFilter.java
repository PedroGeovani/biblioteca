package com.irede.residence.application.filter;

import com.irede.residence.application.security.CustomUserDetails;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.UserRepository;
import com.irede.residence.infra.utils.JwtUtil;
import io.jsonwebtoken.ExpiredJwtException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

@Component
public class CustomJwtAuthenticationFilter extends OncePerRequestFilter {

    Logger logger = LogManager.getLogger(CustomJwtAuthenticationFilter.class);

    private final JwtUtil jwtTokenUtil;
    private final UserRepository userRepository;

    public CustomJwtAuthenticationFilter(JwtUtil jwtTokenUtil, UserRepository userRepository) {
        this.jwtTokenUtil = jwtTokenUtil;
        this.userRepository = userRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        try {
            // JWT Token is in the form "Bearer token". Remove Bearer word and
            // get only the Token
            String jwtToken = extractJwtFromRequest(request);

            if (StringUtils.hasText(jwtToken) && jwtTokenUtil.validateToken(jwtToken)) {
                Optional<User> user = userRepository.findUserByEmail(jwtTokenUtil.getEmail(jwtToken));

                if (user.isEmpty()) {
                    throw new DomainException(ErrorCode.USER_NOT_FOUND);
                }

                CustomUserDetails userDetails = new CustomUserDetails(
                        jwtTokenUtil.getRole(user.get().getRole().toString()), user.get(), jwtToken
                );

                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities());

                // After setting the Authentication in the context, we specify
                // that the current user is authenticated. So it passes the
                // Spring Security Configurations successfully.
                SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
            }
        } catch (ExpiredJwtException ex) {
            tryRefresh(request, ex);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }

        filterChain.doFilter(request, response);
    }

    private void tryRefresh(HttpServletRequest request, ExpiredJwtException ex) {
        String isRefreshToken = request.getHeader("isRefreshToken");
        String requestURL = request.getRequestURL().toString();

        // allow for Refresh Token creation if following conditions are true.
        boolean shouldRefresh = isRefreshToken != null && isRefreshToken.equals("true") &&
                requestURL.contains("refreshtoken");
        if (shouldRefresh) {
            allowForRefreshToken(ex, request);
        }
    }

    private void allowForRefreshToken(ExpiredJwtException ex, HttpServletRequest request) {

        // create a UsernamePasswordAuthenticationToken with null values.
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                null, null, null);
        // After setting the Authentication in the context, we specify
        // that the current user is authenticated. So it passes the
        // Spring Security Configurations successfully.
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
        // Set the claims so that in controller we will be using it to create
        // new JWT
        request.setAttribute("claims", ex.getClaims());
    }

    private String extractJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }
}

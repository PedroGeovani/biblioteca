package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.Rent;
import com.irede.residence.domain.entity.Reserve;
import com.irede.residence.domain.entity.ReserveStatus;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.to.ReserveTO;

import java.util.List;
import java.util.UUID;

public class RentReserveService {

    private final RentService rentService;
    private final ReserveService reserveService;

    public RentReserveService(RentService rentService, ReserveService reserveService) {
        this.rentService = rentService;
        this.reserveService = reserveService;
    }

    public Rent renewRentWithReserveValidation(UUID id) throws DomainException {
        Rent rent = rentService.findById(id);
        Reserve reserve = reserveService.getReserveByBook(rent.getBook());
        return rentService.updateRent(id, reserve);
    }

    public Reserve updateReserve(ReserveTO reserveTO, UUID reserveId) throws DomainException {
        List<Rent> activeRentsByUser = rentService.getAllActiveRentsByUser();
        List<Rent> activeRentsByBook = rentService.getAllActiveRentsByBookId(reserveTO.getBookID());
        return reserveService.updateReserve(reserveTO, reserveId, activeRentsByUser,activeRentsByBook);
    }

    public Reserve createReserve(ReserveTO reserveTO) throws DomainException {
        List<Rent> activeRentsByUser = rentService.getAllActiveRentsByUser();
        List<Rent> activeRentsByBook = rentService.getAllActiveRentsByBookId(reserveTO.getBookID());
        return reserveService.createReserve(reserveTO, activeRentsByUser, activeRentsByBook);
    }
}

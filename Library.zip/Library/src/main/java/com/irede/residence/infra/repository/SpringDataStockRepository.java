package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;
import java.util.UUID;

public interface SpringDataStockRepository extends JpaRepository<Stock, UUID>, JpaSpecificationExecutor<Stock> {
    Optional<Stock> findStockByBookId(UUID bookId);
}

package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.Reserve;
import com.irede.residence.domain.entity.ReserveStatus;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.RentReserveService;
import com.irede.residence.domain.service.ReserveService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.ReserveTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping(value = "/v1/reserves")
@RestController
public class ReserveController {

    private final ReserveService reserveService;
    private final RentReserveService rentReserveService;

    public ReserveController(ReserveService reserveService, RentReserveService rentReserveService) {
        this.reserveService = reserveService;
        this.rentReserveService = rentReserveService;
    }

    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<Reserve>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(value = "dateReserveAvailable", required = false) Date dateReserveAvailable,
            @RequestParam(value = "status", required = false) ReserveStatus reserveStatus,
            @RequestParam(value = "id", required = false) UUID id
            ) {
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        params.put("dateReserveAvailable", dateReserveAvailable);
        params.put("reserveStatus", reserveStatus);
        params.put("id", id);
        paginationTO.setParams(params);

        return ResponseEntity.ok(reserveService.getAll(paginationTO));
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Reserve> findById(@PathVariable UUID id) throws DomainException {
        Reserve reserve = reserveService.findById(id);
        return ResponseEntity.ok().body(reserve);
    }

    @PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Reserve> create(@Valid @RequestBody ReserveTO reserveTO) throws DomainException {
        Reserve reserve = rentReserveService.createReserve(reserveTO);
        return new ResponseEntity<>(reserve, HttpStatus.CREATED);
    }

    @PutMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Reserve> update (@PathVariable("id") UUID id,
                                           @Valid @RequestBody ReserveTO reserveTO) throws DomainException {
        return ResponseEntity.ok(rentReserveService.updateReserve(reserveTO, id));
    }

    @DeleteMapping(value = "{id}")
    public ResponseEntity<Reserve> delete (@PathVariable("id") UUID id) throws DomainException {
        reserveService.deleteReserve(id);
        return ResponseEntity.noContent().build();
    }

}

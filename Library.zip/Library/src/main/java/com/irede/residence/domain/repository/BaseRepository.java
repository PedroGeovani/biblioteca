package com.irede.residence.domain.repository;

import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;

import java.util.Optional;
import java.util.UUID;

public interface BaseRepository<T> {


    PageTO<T> findAll(PaginationTO paginationTO);

    T save(T entity);

    Optional<T> findById(UUID id);
}

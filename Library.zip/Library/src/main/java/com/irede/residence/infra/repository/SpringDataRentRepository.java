package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Rent;
import com.irede.residence.domain.entity.RentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SpringDataRentRepository extends JpaRepository<Rent, UUID>, JpaSpecificationExecutor<Rent> {
    Optional<Rent> findByIdAndDeletedAtIsNull(UUID id);
    List<Rent> findAllByUserIdAndStatusAndDeletedAtIsNull(UUID userId, RentStatus status);
    List<Rent> findAllByBookIdAndStatusAndDeletedAtIsNull(UUID userId, RentStatus status);
}

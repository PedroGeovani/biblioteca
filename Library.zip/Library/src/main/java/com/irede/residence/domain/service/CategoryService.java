package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.Category;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.CategoryRepository;
import com.irede.residence.domain.to.CategoryTO;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public class CategoryService {
    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public PageTO<Category> getAll(PaginationTO paginationTO) {
        return categoryRepository.findAll(paginationTO);
    }

    private Optional<Category> findById(UUID id) throws DomainException {
        Optional<Category> category = categoryRepository.findById(id);
        if (category.isEmpty()) {
            throw new DomainException(ErrorCode.CATEGORY_NOT_FOUND);
        }
        return category;
    }

    public Optional<Category> findCategoryByName(String name) {
        return categoryRepository.findCategoryByName(upperAndSnakeCase(name));
    }

    public Category createCategory(CategoryTO categoryTO) throws DomainException {
        Optional<Category> categoryDB = categoryRepository.findCategoryByName(upperAndSnakeCase(categoryTO.getName()));
        if (categoryDB.isPresent()) {
            throw new DomainException(ErrorCode.CATEGORY_EXISTENT);
        }

        Category category = Category.builder().name(upperAndSnakeCase(categoryTO.getName())).build();

        return categoryRepository.save(category);
    }

    public Category updateCategory(CategoryTO categoryTO, UUID id) throws DomainException {
        Optional<Category> category = findById(id);

        if (!upperAndSnakeCase(categoryTO.getName()).equals(category.get().getName())) {
            Optional<Category> categoryDB = categoryRepository.findCategoryByName(upperAndSnakeCase(categoryTO.getName()));

            if (categoryDB.isPresent()) {
                throw new DomainException(ErrorCode.CATEGORY_EXISTENT);
            }

            category.get().setName(upperAndSnakeCase(categoryTO.getName()));
        }

        return categoryRepository.save(category.get());
    }

    public void deleteCategory(UUID id) throws DomainException {
        Optional<Category> category = findById(id);

        categoryRepository.delete(category.get());
    }

    private String upperAndSnakeCase(String categoryTOString) {
        return categoryTOString.toUpperCase().replace(" ", "_");
    }
}

package com.irede.residence.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "books")
@EqualsAndHashCode(callSuper = true)
public class Book extends BaseEntity {

    @Column(unique = true)
    private String title;

    private String author;

    @Column(unique = true)
    private String isbn;

    private String publisher;

    @Enumerated(EnumType.STRING)
    private BookStatus status;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss*SSSZZZZ")
    private Date publicationDate;
    
    @ManyToMany
    private List<Category> listCategories;

    @JsonIgnore
    @Temporal(TemporalType.DATE)
    @Column(name = "deleted_at")
    private Date deletedAt;

    @JsonIgnore
    @Temporal(TemporalType.DATE)
    @Column(name = "updated_at", nullable = false)
    private Date updatedAt;

    @JsonIgnore
    @Temporal(TemporalType.DATE)
    @Column(name = "created_at", nullable = false)
    private Date createdAT;

    @PrePersist
    protected void onCreate() {
        this.createdAT = new Date();
        this.updatedAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = new Date();
    }
}

package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.BookService;
import com.irede.residence.domain.to.BookTO;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping(value = "/v1/books")
@RestController
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }
    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping(value = "",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<Book>> getAll(
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size",defaultValue = "10") int size,
            @RequestParam(name = "title", required = false) String title,
            @RequestParam(name = "isbn", required = false) String isbn,
            @RequestParam(name = "author", required = false) String author,
            @RequestParam(name = "status", required = false) BookStatus status,
            @RequestParam(name = "id", required = false) UUID id
            ){
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        params.put("title", title);
        params.put("isbn", isbn);
        params.put("author", author);
        params.put("status", status);
        params.put("id", id);
        paginationTO.setParams(params);

        return ResponseEntity.ok(bookService.getAll(paginationTO));
    }

    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Book> create(@Valid @RequestBody BookTO bookTO) throws DomainException {
        return new ResponseEntity<>(bookService.createBook(bookTO), HttpStatus.CREATED);
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Book> update(@Valid @RequestBody BookTO bookTo,
                                       @PathVariable("id") UUID id) throws DomainException {
        return ResponseEntity.ok(bookService.updateBook(bookTo, id));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> delete(@PathVariable("id") UUID id) throws DomainException {
        bookService.deleteBook(id);
        return ResponseEntity.ok().build();
    }
}

package com.irede.residence.domain.to;

import lombok.*;

import javax.validation.constraints.*;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class StockTO {

    @NotNull
    private UUID bookID;

    @Min(value = 1, message = "Total quantity must be at least 1")
    private Integer totalQuantity;
}

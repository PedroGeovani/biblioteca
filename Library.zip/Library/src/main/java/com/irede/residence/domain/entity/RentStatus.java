package com.irede.residence.domain.entity;

public enum RentStatus {
    ACTIVE,
    INACTIVE,
}

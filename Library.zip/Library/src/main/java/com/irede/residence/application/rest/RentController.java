package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.Rent;
import com.irede.residence.domain.entity.RentStatus;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.RentReserveService;
import com.irede.residence.domain.service.RentService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.RentTO;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
@RequestMapping(value = "v1/rents")
public class RentController {

    private final RentService rentService;
    private final RentReserveService rentReserveService;

    public RentController(RentService rentService, RentReserveService rentReserveService) {
        this.rentService = rentService;
        this.rentReserveService = rentReserveService;
    }

    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<Rent>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(value = "status", required = false) RentStatus status,
            @RequestParam(value = "rentFinalDate", required = false)
                @DateTimeFormat(pattern = "yyyy/MM/dd") Date rentFinalDate
            ){
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        params.put("status", status);
        params.put("rentFinalDate", rentFinalDate);
        paginationTO.setParams(params);

        return ResponseEntity.ok(rentService.getAll(paginationTO));
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Rent> findById(@PathVariable UUID id) throws DomainException {
        Rent rent = rentService.findById(id);
        return ResponseEntity.ok().body(rent);
    }

    @PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Rent> createRent(@Valid @RequestBody RentTO rentTO) throws DomainException {
        Rent rent = rentService.createRent(rentTO);
        return new ResponseEntity<>(rent, HttpStatus.CREATED);
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Rent> updateRent(@PathVariable UUID id) throws DomainException {
        Rent rent = rentReserveService.renewRentWithReserveValidation(id);
        return ResponseEntity.ok(rent);
    }

    @PatchMapping(value = "returnal/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Rent> returnRent(@PathVariable UUID id) throws DomainException {
        Rent rent = rentService.returnRent(id);
        return ResponseEntity.ok(rent);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> deleteRent(@PathVariable UUID id) throws DomainException {
        rentService.deleteRent(id);
        return ResponseEntity.noContent().build();
    }
}



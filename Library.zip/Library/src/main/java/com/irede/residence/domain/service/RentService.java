package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.*;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.RentRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.RentTO;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class RentService {

    private final RentRepository rentRepository;

    private final UserService userService;

    private final Integer limitRent;

    private static final int RENT_DAYS = 15;

    private final StockService stockService;
    
    public RentService(RentRepository rentRepository,
                       UserService userService,
                       Integer limitRent, StockService stockService) {
        this.rentRepository = rentRepository;
        this.userService = userService;
        this.limitRent = limitRent;
        this.stockService = stockService;
    }

    public PageTO<Rent> getAll(PaginationTO paginationTO) {
        return rentRepository.findAll(paginationTO);
    }

    public Rent findById(UUID id) throws DomainException {
        return rentRepository.findById(id)
                .orElseThrow(() -> new DomainException(ErrorCode.RENT_NOT_FOUND));
    }

    public Rent createRent(RentTO rentTO) throws DomainException {

        Book book = stockService.updateAvailableQuantity(rentTO.getBookId(),-1);
        User user = userService.getUserJwt();

        Date rentFinalDate = calculateRentFinalDate(new Date(), RENT_DAYS);

        Rent rent = Rent.builder()
                .book(book)
                .user(user)
                .rentFinalDate(rentFinalDate)
                .countRent(0).status(RentStatus.ACTIVE)
                .build();

        return rentRepository.save(rent);
    }

    public Rent updateRent(UUID id, Reserve reserve) throws DomainException {
        Rent rent = this.findById(id);
        Stock stock = stockService.getStockIfExistsByBookId(rent.getBook().getId());

        Date currentRentFinalDate = rent.getRentFinalDate();
        Date newRentFinalDate = calculateRentFinalDate(currentRentFinalDate, RENT_DAYS);
        rent.setRentFinalDate(newRentFinalDate);
        rent.setCountRent(rent.getCountRent() + 1);

        if (rent.getCountRent() > limitRent) {
            throw new DomainException("Exceeded rent limit", ErrorCode.RENT_LIMIT);
        }

        if(reserve.getReserveStatus() == ReserveStatus.UNAVAILABLE && stock.getAvailableQuantity() == 0){
            throw new DomainException("Book is reserved and cannot be rented again", ErrorCode.BOOK_RESERVED);
        }

        return rentRepository.save(rent);
    }

    public void deleteRent(UUID id) throws DomainException {
        Rent rent = this.findById(id);
        rent.setDeletedAt(new Date());
        rentRepository.save(rent);
    }

    public Rent returnRent(UUID id) throws DomainException {
        Rent rent = this.findById(id);

        if (rent.getStatus() == RentStatus.INACTIVE) {
            throw new DomainException("Rent already returned", ErrorCode.RENT_ALREADY_RETURNED);
        }

        stockService.updateAvailableQuantity(rent.getBook().getId(),1);
        rent.setStatus(RentStatus.INACTIVE);
        rent.setRentFinalDate(new Date());
        return rentRepository.save(rent);
    }


    private Date calculateRentFinalDate(Date startDate, int rentDays) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        calendar.add(Calendar.DAY_OF_MONTH, rentDays);
        return calendar.getTime();
    }

    public List<Rent> getAllActiveRentsByUser() {
        User User = userService.getUserJwt();
        return rentRepository.findAllActiveRentsByUserId(User.getId());
    }

    public List<Rent> getAllActiveRentsByBookId(UUID bookId) {
        return rentRepository.findAllActiveRentsByBookId(bookId);
    }
}

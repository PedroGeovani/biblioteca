package com.irede.residence.domain.repository;

import com.irede.residence.domain.entity.Category;

import java.util.Optional;

public interface CategoryRepository extends BaseRepository<Category> {
    Optional<Category> findCategoryByName(String name);

    void delete(Category category);
}

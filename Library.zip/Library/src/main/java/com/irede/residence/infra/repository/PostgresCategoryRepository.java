package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Category;
import com.irede.residence.domain.repository.CategoryRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class PostgresCategoryRepository implements CategoryRepository {
    private final SpringDataCategoryRepository categoryRepository;

    public PostgresCategoryRepository(SpringDataCategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Optional<Category> findCategoryByName(String name) {
        return categoryRepository.findCategoryByName(name);
    }

    @Override
    public void delete(Category category) {
        categoryRepository.delete(category);
    }

    @Override
    public PageTO<Category> findAll(PaginationTO paginationTO) {
        Pageable pageable = PageRequest.of(paginationTO.getPage(), paginationTO.getSize());
        Page<Category> categories = categoryRepository.findAll(pageable);
        return new PageTO<>(categories.getContent(), categories.getTotalElements(), categories.getNumber(),
                categories.getSize());
    }

    @Override
    public Category save(Category entity) {
        return categoryRepository.save(entity);
    }

    @Override
    public Optional<Category> findById(UUID id) {
        return categoryRepository.findById(id);
    }
}

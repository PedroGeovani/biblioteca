package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.*;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.ReserveRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.ReserveTO;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ReserveService {

    private final ReserveRepository reserveRepository;
    private final UserService userService;
    private final StockService stockService;
    private final BookService bookService;
    private final CustomUserDetailsService customUserDetailsService;
    private final Integer LIMIT_RESERVES = 2;

    public ReserveService(ReserveRepository reserveRepository,
                          UserService userService,
                          BookService bookService,
                          CustomUserDetailsService customUserDetailsService,
                          StockService stockService) {

        this.reserveRepository = reserveRepository;
        this.userService = userService;
        this.bookService = bookService;
        this.customUserDetailsService = customUserDetailsService;
        this.stockService = stockService;
    }

    public PageTO<Reserve> getAll(PaginationTO paginationTO) {
        User user = customUserDetailsService.getUser();
        if(user.getRole().equals(Role.STUDENT)){
            paginationTO.getParams().put("id", user.getId());
            return reserveRepository.findAll(paginationTO);
        }

        return reserveRepository.findAll(paginationTO);
    }

    public Reserve findById(UUID id) throws DomainException {
        Optional<Reserve> reserve = reserveRepository.findById(id);
        if (reserve.isEmpty()) {
            throw new DomainException("We could not find your reserve", ErrorCode.RESERVE_NOT_FOUND);
        }
        return reserve.get();
    }

    public Reserve createReserve(ReserveTO reserveTO,
                                 List<Rent> activeRentsByUser,
                                 List<Rent> activeRentsByBook) throws DomainException {

        UUID userId = customUserDetailsService.getUser().getId();
        User user = userService.getById(userId);
        Book book = bookService.findById(reserveTO.getBookID());

        verifyIfUserIsTryingReserveABookHeRented(book, userId, activeRentsByUser);
        verifyExistentReserveForBookMadeByUser(book);
        verifyAvailableBooksOnStock(book);
        verifyLimitReserve(user.getId());

        Reserve reserve = Reserve.builder()
                .user(user)
                .book(book)
                .reserveStatus(ReserveStatus.UNAVAILABLE)
                .dateReserveCreated(new Date())
                .dateReserveAvailable(returnReserveDateByRentFinalDate(book, activeRentsByBook))
                .build();

        return reserveRepository.save(reserve);
    }

    public Reserve updateReserve(ReserveTO reserveTO,
                                 UUID id,
                                 List<Rent> activeRentsByUser,
                                 List<Rent> activeRentsByBook) throws DomainException {

        UUID userId = customUserDetailsService.getUser().getId();
        Reserve reserve = this.findById(id);
        Book book = this.bookService.findById(reserveTO.getBookID());

        verifyIfUserIsTryingReserveABookHeRented(book, userId, activeRentsByUser);
        verifyExistentReserveForBookMadeByUser(book);
        verifyLimitReserve(userId);
        verifyAvailableBooksOnStock(book);

        reserve.setBook(book);
        reserve.setDateReserveAvailable(returnReserveDateByRentFinalDate(book, activeRentsByBook));
        reserve.setReserveStatus(ReserveStatus.UNAVAILABLE);

        return reserveRepository.save(reserve);
    }

    public void deleteReserve(UUID id) throws DomainException {
        Reserve reserve = this.findById(id);
        reserveRepository.delete(reserve);
    }

    public void verifyLimitReserve(UUID userId) throws DomainException {
        Integer qtdReserve = reserveRepository.verifyLimitReserves(userId);

        if (qtdReserve >= LIMIT_RESERVES) {
            throw new DomainException("You have reached the reserve limit", ErrorCode.LIMIT_RESERVES_REACHED);
        }
    }

    public List<Optional<Reserve>> getAllUserReserves() throws DomainException {
        UUID userId = customUserDetailsService.getUser().getId();
        return reserveRepository.findReserveByUserId(userId);
    }

    public Reserve getReserveByBook(Book book) throws DomainException {
        List<Optional<Reserve>> reserve = reserveRepository.findReserveByBookTitle(book.getTitle());
        return reserve.get(0).get();
    }

    private List<Optional<Reserve>> getAllReservesByBook(Book book){
        return reserveRepository.findReserveByBookTitle(book.getTitle());
    }

    private void verifyIfUserIsTryingReserveABookHeRented(Book book, UUID id, List<Rent> rents) throws DomainException {

        for (Rent rent : rents) {
            if (rent.getBook().getId().equals(book.getId())
                    && rent.getUser().getId().equals(id)) {
                throw new DomainException("You can't reserve a book that was rented by you.", ErrorCode.CANT_RESERVE_A_BOOK_RENTEND_BY_YOU);
            }
        }
    }

    private void verifyAvailableBooksOnStock(Book book) throws DomainException {
        Stock bookOnStock = stockService.getStockIfExistsByBookId(book.getId());

        if (bookOnStock.getAvailableQuantity() > 0) {
            throw new DomainException("There are books available to rent on stock", ErrorCode.BOOK_AVAILABLE_TO_RENT);
        }
    }

    private void verifyExistentReserveForBookMadeByUser(Book book) throws DomainException {
        List<Optional<Reserve>> reserves = getAllUserReserves();

        for (Optional<Reserve> reserve : reserves) {
            if (reserve.get().getBook().getId().equals(book.getId())) {
                throw new DomainException("It already has a reserve for this book by yourself", ErrorCode.RESERVE_EXISTENT);
            }
        }
    }

    private Date returnReserveDateByRentFinalDate(Book book, List<Rent> rents) throws DomainException {
        List<Optional<Reserve>> reserves = getAllReservesByBook(book);
        Date reserveDate = returnTheEarliestRentFinalDate(rents);
        Date existentReserveVerification = verifyIfAReserveAlreadyExistsByBookAndDate(reserves, reserveDate);

        while (existentReserveVerification == null) {
            rents = removeTheElementFromRentList(rents, reserveDate);
            reserveDate = returnTheEarliestRentFinalDate(rents);
            existentReserveVerification = verifyIfAReserveAlreadyExistsByBookAndDate(reserves, reserveDate);
        }

        return reserveDate;
    }

    private Date verifyIfAReserveAlreadyExistsByBookAndDate(List<Optional<Reserve>> reserves, Date reserveDate) throws DomainException {

        if(reserves.isEmpty()) {
            return reserveDate;
        }

        for (Optional<Reserve> reserve : reserves) {
            if (reserve.get().getDateReserveAvailable().equals(reserveDate)) {
                return null;
            }
        }
        return reserveDate;
    }

    private Date returnTheEarliestRentFinalDate(List<Rent> rents) throws DomainException {

        if (rents.isEmpty()) {
            throw new DomainException(ErrorCode.BOOK_AVAILABLE_TO_RENT);
        }

        return Collections.min(rents.stream()
                .map(Rent::getRentFinalDate)
                .toList());
    }

    private List<Rent> removeTheElementFromRentList(List<Rent> rents, Date reserveDate) {
        Predicate<Rent> bookReserved = rent -> reserveDate == rent.getRentFinalDate();
        rents.removeIf(bookReserved);
        return rents;
    }

    public void updateReserveStatus(UUID bookId) throws DomainException {
        Reserve reserve = returnUserReserveByBookId(bookId);

        if(reserve.getBook().getStatus().equals(BookStatus.AVAILABLE)){
            reserve.setReserveStatus(ReserveStatus.AVAILABLE);
        }
    }

    public Reserve returnUserReserveByBookId(UUID bookId) throws DomainException {

        List<Optional<Reserve>> reservesByBook = getAllReservesByBook(bookService.findById(bookId));
        UUID userId = customUserDetailsService.getUser().getId();

        if (reservesByBook.isEmpty()){
            throw new DomainException(ErrorCode.NO_RESERVES_EXISTENT_FOR_BOOK);
        }
        for (Optional<Reserve> reserve : reservesByBook){
            if(reserve.get().getUser().getId().equals(userId)){
                return reserve.get();
            }
        }
        return null;
    }
}

package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.Category;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.CategoryService;
import com.irede.residence.domain.to.CategoryTO;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping(value = "/v1/categories")
@RestController
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<Category>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        paginationTO.setParams(params);

        return ResponseEntity.ok(categoryService.getAll(paginationTO));
    }

    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Category> create(@Valid @RequestBody CategoryTO categoryTO) throws DomainException {
        return new ResponseEntity<Category>(categoryService.createCategory(categoryTO), HttpStatus.CREATED);
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Category> update(@Valid @RequestBody CategoryTO categoryTO,
                                           @PathVariable("id") UUID id) throws DomainException {
        return ResponseEntity.ok(categoryService.updateCategory(categoryTO, id));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> delete(@PathVariable("id") UUID id) throws DomainException {
        categoryService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }
}

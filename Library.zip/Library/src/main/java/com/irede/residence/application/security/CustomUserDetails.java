package com.irede.residence.application.security;

import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.stream.Collectors;

@Getter
public class CustomUserDetails  extends User {
    private final com.irede.residence.domain.entity.User user;
    private final String JWT;

    public CustomUserDetails(
            Collection<? extends GrantedAuthority> authorities,
            com.irede.residence.domain.entity.User user,
            String JWT
    ) {
        super(user.getName(), user.getPassword(), authorities);
        this.user = user;
        this.JWT = JWT;
    }

    public List<String> getGrantedRoles() {
        return this.getAuthorities().stream().map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
    }

    public String getRole() {
        return user.getRole().name();
    }

    public String getEmail() {
        return user.getEmail();
    }

    public UUID getUserid() {
        return user.getId();
    }


    public String getJWT() {
        if (JWT == null) {
            throw new NoSuchElementException();
        }

        return JWT;
    }
}

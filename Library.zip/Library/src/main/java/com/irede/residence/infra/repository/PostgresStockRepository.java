package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.repository.StockRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import java.util.*;

@Component
public class PostgresStockRepository implements StockRepository {
    private final SpringDataStockRepository stockRepository;

    public PostgresStockRepository(SpringDataStockRepository stockRepository) {
        this.stockRepository = stockRepository;
    }

    @Override
    public Optional<Stock> findStockByBookId(UUID bookId) {
        return stockRepository.findStockByBookId(bookId);
    }

    @Override
    public void delete(Stock stock) {
        stockRepository.delete(stock);
    }

    @Override
    public PageTO<Stock> findAll(PaginationTO paginationTO) {
        Pageable pageable = PageRequest.of(paginationTO.getPage(), paginationTO.getSize());
        Page<Stock> stocks = stockRepository.findAll(getAllStocks(paginationTO.getParams()), pageable);
        return new PageTO<>(stocks.getContent(), stocks.getTotalElements(), stocks.getNumber(),
                stocks.getSize());
    }

    private Specification<Stock> getAllStocks(Map<String, Object> params) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            Join<Stock, Book> bookJoin = root.join("book");

            if (params.containsKey("status") && params.get("status") != null) {
                predicates.add(cb.equal(bookJoin.get("status"), params.get("status")));
            }

            return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }

    @Override
    public Stock save(Stock entity) {
        return stockRepository.save(entity);
    }

    @Override
    public Optional<Stock> findById(UUID id) {
        return stockRepository.findById(id);
    }
}

package com.irede.residence.infra.utils;

import com.irede.residence.application.security.CustomUserDetails;
import com.irede.residence.domain.entity.Role;
import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class JwtUtil {

    private String secret;
    private int jwtExpirationInMs;
    private int refreshExpirationDateInMs;

    @Value("${jwt.secret}")
    public void setSecret(String secret) {
        this.secret = secret;
    }

    private byte[] getSecret() {
        return secret.getBytes(StandardCharsets.UTF_8);
    }

    @Value("${jwt.expirationDateInMs}")
    public void setJwtExpirationInMs(int jwtExpirationInMs) {
        this.jwtExpirationInMs = jwtExpirationInMs;
    }

    @Value("${jwt.refreshExpirationDateInMs}")
    public void setRefreshExpirationDateInMs(int refreshExpirationDateInMs) {
        this.refreshExpirationDateInMs = refreshExpirationDateInMs;
    }

    public String generateToken(CustomUserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();

        Collection<? extends GrantedAuthority> roles = userDetails.getAuthorities();

        if (roles.contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
            claims.put("isAdmin", true);
        }
        if (roles.contains(new SimpleGrantedAuthority("ROLE_TEACHER"))) {
            claims.put("isTeacher", true);
        }
        if (roles.contains(new SimpleGrantedAuthority("ROLE_STUDENT"))) {
            claims.put("isStudent", true);
        }
        if (roles.contains(new SimpleGrantedAuthority("ROLE_APPLICATION_ADMIN"))) {
            claims.put("isApplicationAdmin", true);
        }

        Map<String, Object> objectMap = new HashMap<>();

        claims.put("UserName", userDetails.getUsername());
        claims.put("Userid", userDetails.getUserid());
        claims.put("email", userDetails.getEmail());

        return doGenerateToken(claims, userDetails.getUsername());
    }

    public Collection<? extends GrantedAuthority> getRole(String roleUser) {
        Collection<? extends GrantedAuthority> roles = null;
        if (roleUser != null && roleUser.equals(Role.ADMINISTRATOR.toString())) {
            roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
        } else if (roleUser != null && roleUser.equals(Role.STUDENT.toString())) {
            roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_STUDENT"));
        }

        return roles;
    }

    private String doGenerateToken(Map<String, Object> claims, String subject) {

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationInMs))
                .signWith(SignatureAlgorithm.HS512, getSecret()).compact();

    }

    private Claims getJWTBody(String token) {
        return Jwts.parser().setSigningKey(getSecret()).parseClaimsJws(token).getBody();
    }

    public String doGenerateRefreshToken(Map<String, Object> claims, String subject) {

        return Jwts.builder().setClaims(claims).setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + refreshExpirationDateInMs))
                .signWith(SignatureAlgorithm.HS512, getSecret()).compact();

    }

    public boolean validateToken(String authToken) {
        try {
            Jws<Claims> claims = Jwts.parser().setSigningKey(getSecret()).parseClaimsJws(authToken);
            return true;
        } catch (MalformedJwtException | UnsupportedJwtException | IllegalArgumentException ex) {
            throw new BadCredentialsException("INVALID_CREDENTIALS", ex);
        } catch (ExpiredJwtException ex) {
            throw ex;
        }
    }

    public String getUsernameFromToken(String token) {
        Claims claims = getJWTBody(token);
        return claims.getSubject();

    }

    public String getUserName(String token) {
        Claims claims = getJWTBody(token);
        return claims.get("UserName", String.class);
    }

    public String getUserId(String token) {
        Claims claims = getJWTBody(token);
        return claims.get("Userid", String.class);
    }

    public String getEmail(String token) {
        Claims claims = getJWTBody(token);
        return claims.get("email", String.class);
    }

    public List<SimpleGrantedAuthority> getRolesFromToken(String token) {
        Claims claims = getJWTBody(token);

        List<SimpleGrantedAuthority> roles = null;

        Boolean isAdmin = claims.get("isAdmin", Boolean.class);
        Boolean isStudent = claims.get("isStudent", Boolean.class);
        Boolean isTeacher = claims.get("isTeacher", Boolean.class);

        if (isAdmin != null && isAdmin) {
            roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
        } else if (isTeacher != null && isTeacher) {
            roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_TEACHER"));
        } else if (isStudent != null && isStudent) {
            roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_STUDENT"));
        }

        return roles;

    }
}

package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.repository.BookRepository;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Predicate;

@Component
public class PostgresBookRepository implements BookRepository {
    private final SpringDataBookRepository bookRepository;

    public PostgresBookRepository(SpringDataBookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public PageTO<Book> findAll(PaginationTO paginationTO) {
        Pageable pageable = Pageable.ofSize(paginationTO.getSize()).withPage(paginationTO.getPage());
        Page<Book>all = bookRepository.findAll(getAllBooks(paginationTO.getParams()), pageable);
        return new PageTO<>(all.getContent(), all.getTotalElements(), all.getNumber(),all.getSize());
    }

    private Specification<Book> getAllBooks(Map<String, Object> params) {
        return (root, query, cb) -> {
            List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();

            predicates.add(cb.isNull(root.get("deletedAt")));

            if (params.containsKey("title") && params.get("title") != null) {
                predicates.add(cb.like(
                        (root.get("title")), "%" + params.get("title").toString() + "%"));
            }

            if (params.containsKey("isbn") && params.get("isbn") != null) {
                predicates.add(cb.equal(root.get("isbn"), params.get("isbn")));
            }

            if (params.containsKey("author") && params.get("author") != null) {
                predicates.add(cb.like(root.get("author"), "%" + params.get("author") + "%"));
            }

            if (params.containsKey("status") && params.get("status") != null) {
                predicates.add(cb.equal(root.get("status"), params.get("status")));
            }

            if (params.containsKey("id") && params.get("id") != null) {
                predicates.add(cb.equal(root.get("id"), params.get("id")));
            }

            return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }

    @Override
    public Optional<Book> findByIsbn(String isbn) {
        return bookRepository.findByIsbnAndAndDeletedAtIsNull(isbn);
    }

    @Override
    public Book save(Book entity) {
        return bookRepository.save(entity);
    }

    @Override
    public Optional<Book> findById(UUID id) {
        return bookRepository.findByIdAndDeletedAtIsNull(id);
    }

    @Override
    public Optional<Book> findByTitle(String title) {
        return bookRepository.findByTitleAndDeletedAtIsNull(title);
    }

}

package com.irede.residence.domain.repository;

import com.irede.residence.domain.entity.User;

import java.util.Optional;

public interface UserRepository extends BaseRepository<User> {
    Optional<User> findUserByEmail(String email);
}

package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.entity.Category;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.BookRepository;
import com.irede.residence.domain.to.BookTO;
import com.irede.residence.domain.to.CategoryTO;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;

import java.util.*;

public class BookService {

    private final BookRepository bookRepository;
    private final CategoryService categoryService;

    public BookService(BookRepository bookRepository, CategoryService categoryService) {

        this.bookRepository = bookRepository;
        this.categoryService = categoryService;
    }

    public PageTO<Book> getAll(PaginationTO paginationTO) {
        return bookRepository.findAll(paginationTO);
    }

    public Book createBook(BookTO bookTO) throws DomainException {
        verifyBeforeCreateABook(bookTO);

        Book book = Book.builder()
                .title(bookTO.getTitle())
                .author(bookTO.getAuthor())
                .status(bookTO.getStatus())
                .isbn(bookTO.getIsbn())
                .publisher(bookTO.getPublisher())
                .listCategories(extractCategoryFromBookTo(bookTO.getListCategories()))
                .publicationDate(bookTO.getPublicationDate())
                .build();
        return bookRepository.save(book);
    }

    public Book updateBook(BookTO bookTO, UUID id) throws DomainException {

        verifyBeforeUpdateABook(bookTO, id);

        Book book = this.findById(id);

        book.setTitle(bookTO.getTitle());
        book.setAuthor(bookTO.getAuthor());
        book.setStatus(bookTO.getStatus());
        book.setIsbn(bookTO.getIsbn());
        book.setPublisher(bookTO.getPublisher());
        book.setPublicationDate(bookTO.getPublicationDate());
        book.setListCategories(extractCategoryFromBookTo(bookTO.getListCategories()));

        return bookRepository.save(book);
    }

    public void deleteBook(UUID id) throws DomainException {
        Book book = this.findById(id);

        book.setDeletedAt(new Date());
        book.setUpdatedAt(new Date());

        bookRepository.save(book);
    }

    public Book findByIsbn(String isbn) throws DomainException {
        Optional<Book> book = bookRepository.findByIsbn(isbn);

        if (book.isEmpty()) {
            throw new DomainException(ErrorCode.BOOK_NOT_FOUND);
        }

        return book.get();
    }

    public Book findById(UUID id) throws DomainException {
        Optional<Book> book = bookRepository.findById(id);

        if (book.isEmpty()) {
            throw new DomainException(ErrorCode.BOOK_NOT_FOUND);
        }

        return book.get();
    }

    public List<Category> extractCategoryFromBookTo(List<CategoryTO> categories) throws DomainException {
        List<Category> categoryListExtractedFromBookTo = new ArrayList<>();
        for (CategoryTO category : categories) {
            Optional<Category> categoryDB = categoryService.findCategoryByName(category.getName());
            if (categoryDB.isPresent()) {
                categoryListExtractedFromBookTo.add(categoryDB.get());
            } else {
                categoryListExtractedFromBookTo.add(categoryService.createCategory(new CategoryTO(category.getName())));
            }
        }
        return categoryListExtractedFromBookTo;
    }

    public Book findByTitle(String title) throws DomainException {
        Optional<Book> book = bookRepository.findByTitle(title);

        if (book.isEmpty()) {
            throw new DomainException(ErrorCode.BOOK_NOT_FOUND);
        }

        return book.get();
    }

    public void updateBookStatus(Book book, BookStatus status) {
        book.setStatus(status);
        bookRepository.save(book);
    }

    private void verifyBeforeCreateABook(BookTO bookTo) throws DomainException {
        Optional<Book> bookTitle = bookRepository.findByTitle(bookTo.getTitle());
        Optional<Book> bookIsbn = bookRepository.findByIsbn(bookTo.getIsbn());

        if(bookTitle.isPresent() || bookIsbn.isPresent()){
            throw new DomainException(ErrorCode.BOOK_EXISTENT);
        }
    }

    private void verifyBeforeUpdateABook(BookTO bookTo, UUID id) throws DomainException {
        Optional<Book> bookTitle = bookRepository.findByTitle(bookTo.getTitle());
        Optional<Book> bookIsbn = bookRepository.findByIsbn(bookTo.getIsbn());

        if(bookTitle.equals(bookIsbn)){
            return;
        } else if (bookTitle.isPresent() && bookTitle.get().getId().equals(id) && bookIsbn.isEmpty()) {
            return;
        } else if (bookIsbn.isPresent() && bookIsbn.get().getId().equals(id) && bookTitle.isEmpty()) {
            return;
        } else if(bookTitle.isPresent() && bookTitle.get().getId().equals(id) && bookIsbn.isPresent()){
            throw new DomainException(ErrorCode.BOOK_ISBN_EXISTENT);
        } else if (bookIsbn.isPresent() && bookIsbn.get().getId().equals(id) && bookTitle.isPresent()) {
            throw new DomainException(ErrorCode.BOOK_TITLE_EXISTENT);
        }
    }
}

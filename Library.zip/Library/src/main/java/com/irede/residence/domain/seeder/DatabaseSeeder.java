package com.irede.residence.domain.seeder;

import com.irede.residence.domain.entity.Role;
import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.UserService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.UserTO;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class DatabaseSeeder {

    private final UserService userService;

    public DatabaseSeeder(UserService userService) {
        this.userService = userService;
    }

    @EventListener
    public void seeder(ContextRefreshedEvent event) throws DomainException {
        this.UserSeeder();
    }

    private void UserSeeder() throws DomainException {
        String password = "@irede1234";
        PaginationTO paginationTO =  new PaginationTO(0,10);
        PageTO<User> userPageTO= userService.getAll(paginationTO);
        if(userPageTO.getContent().isEmpty()){
            UserTO userTO = UserTO.builder().name("user adm").phone("1231615868").email("adm@irede.com").role(Role.ADMINISTRATOR)
                    .password(password).confirmPassword(password).build();
            userService.createUser(userTO);
        }
    }
}

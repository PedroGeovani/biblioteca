package com.irede.residence.domain.to;

import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.entity.Category;
import lombok.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookTO {

    @NotNull
    @NotBlank
    private String title;

    @NotNull
    @NotBlank
    private String author;

    @NotNull
    private BookStatus status;

    @NotNull
    @NotBlank
    private String isbn;

    @NotNull
    @NotBlank
    private String publisher;

    @NotNull
    private Date publicationDate;

   @NotEmpty
    private List<CategoryTO> listCategories;

}

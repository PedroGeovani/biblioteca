package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Reserve;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SpringDataReserveRepository extends JpaRepository<Reserve, UUID>, JpaSpecificationExecutor<Reserve> {
    List<Optional<Reserve>>findReserveByBookTitle(String bookTitle);
    Integer countReservesByUserId(UUID userId);
    List<Optional<Reserve>> findReserveByUserId(UUID userId);
}

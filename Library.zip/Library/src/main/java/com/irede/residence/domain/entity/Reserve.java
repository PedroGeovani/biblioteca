package com.irede.residence.domain.entity;

import lombok.*;
import javax.persistence.*;
import java.util.Date;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "reserves")
@EqualsAndHashCode(callSuper = true)
public class Reserve extends BaseEntity{

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @Enumerated(EnumType.STRING)
    @Column(name = "reserve_status", nullable = false)
    private ReserveStatus reserveStatus;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_reserve_available", nullable = false)
    private Date dateReserveAvailable;

    @Temporal(TemporalType.DATE)
    @Column(name = "date_reserve_created", nullable = false)
    private Date dateReserveCreated;

    @PrePersist
    protected void onCreate() {
        this.dateReserveCreated = new Date();
    }

}

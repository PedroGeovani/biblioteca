package com.irede.residence.domain.to;

import lombok.*;

import javax.validation.constraints.Min;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class StockWithoutBookTO {
    @Min(value = 1, message = "Total quantity must be at least 1")
    private Integer totalQuantity;
}

package com.irede.residence.application.security;

import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.repository.UserRepository;
import com.irede.residence.domain.service.CustomUserDetailsService;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CustomUserDetailsServiceImpl implements
        UserDetailsService, CustomUserDetailsService {

    private final UserRepository userRepository;
    private final SecurityContextHolderFacade securityContextHolderFacade;

    public CustomUserDetailsServiceImpl(UserRepository userRepository,
                                        SecurityContextHolderFacade securityContextHolderFacade) {
        this.userRepository = userRepository;
        this.securityContextHolderFacade = securityContextHolderFacade;
    }

    @Override
    public CustomUserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        List<SimpleGrantedAuthority> roles;

        Optional<User> user = userRepository.findUserByEmail(username);
        if (user.isPresent()) {
            User loggedUser = user.get();

            roles = List.of(
                    new SimpleGrantedAuthority(getRoleFromUserType(loggedUser.getRole().name()))
            );

            CustomUserDetails customUserDetails = new CustomUserDetails(roles, loggedUser, null);
            return customUserDetails;
        }

        throw new UsernameNotFoundException("User not found with the name " + username);
    }

    @Override
    public UUID getIdUserDetails() {
        CustomUserDetails customUserDetails = getCustomUserDetails();
        return customUserDetails.getUserid();
    }

    @Override
    public User getUser() {
        CustomUserDetails customUserDetails = getCustomUserDetails();
        return customUserDetails.getUser();
    }

    @Override
    public Boolean isAuthenticated() {
        return securityContextHolderFacade.isAuthenticated();
    }

    private CustomUserDetails getCustomUserDetails() {
        return securityContextHolderFacade.getCustomUserDetails();
    }

    private String getRoleFromUserType(String userType) {
        if (userType == null || userType.equals("STUDENT")) {
            return "ROLE_STUDENT";
        } else if (userType.equals("APPLICATION_ADMIN")) {
            return "ROLE_APPLICATION_ADMIN";
        } else if (userType.equals("ADMINISTRATOR")) {
            return "ROLE_ADMIN";
        } else if (userType.equals("TEACHER")) {
            return "ROLE_TEACHER";
        }

        return "";
    }
}

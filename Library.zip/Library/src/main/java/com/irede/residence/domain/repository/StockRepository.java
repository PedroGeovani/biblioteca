package com.irede.residence.domain.repository;

import com.irede.residence.domain.entity.Stock;

import java.util.Optional;
import java.util.UUID;

public interface StockRepository extends BaseRepository<Stock> {
    Optional<Stock> findStockByBookId(UUID bookId);
    void delete(Stock stock);
}

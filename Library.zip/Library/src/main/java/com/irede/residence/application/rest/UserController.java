package com.irede.residence.application.rest;

import com.irede.residence.domain.entity.User;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.service.UserService;
import com.irede.residence.domain.to.PageTO;
import com.irede.residence.domain.to.PaginationTO;
import com.irede.residence.domain.to.UserTO;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping(value = "/v1/user")
@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PageTO<User>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        PaginationTO paginationTO = new PaginationTO(page, size);
        Map<String, Object> params = new HashMap<>();
        paginationTO.setParams(params);

        return ResponseEntity.ok(userService.getAll(paginationTO));
    }

    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<User> create(@Valid @RequestBody UserTO userTO) throws DomainException {
        return ResponseEntity.ok(userService.createUser(userTO));
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<User> update(@Valid @RequestBody UserTO userTO,
                                       @PathVariable("id") UUID id) throws DomainException {
        return ResponseEntity.ok(userService.updateUser(userTO, id));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> delete(@PathVariable("id") UUID id) throws DomainException {
        userService.deleteUser(id);
        return ResponseEntity.ok().build();
    }

}

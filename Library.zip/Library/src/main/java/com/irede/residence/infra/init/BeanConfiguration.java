package com.irede.residence.infra.init;

import com.irede.residence.application.security.CustomUserDetailsServiceImpl;
import com.irede.residence.domain.repository.StockRepository;
import com.irede.residence.domain.repository.*;
import com.irede.residence.domain.service.*;
import com.irede.residence.domain.repository.UserRepository;
import com.irede.residence.domain.service.AuthenticationService;
import com.irede.residence.domain.repository.BookRepository;
import com.irede.residence.domain.repository.CategoryRepository;
import com.irede.residence.domain.utils.EncryptService;
import com.irede.residence.infra.utils.EncryptServiceImpl;
import com.irede.residence.infra.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class BeanConfiguration {

    @Bean
    UserService userService(UserRepository userRepository, EncryptService encryptService,
                            CustomUserDetailsService customUserDetailsService){
        return  new UserService(userRepository, encryptService, customUserDetailsService);
    }

    @Bean
    RentService rentService(RentRepository rentRepository,
                            UserService userService,
                            @Value("${rent.limit}") Integer limitRent,
                            StockService stockService) {
        return new RentService(rentRepository, userService, limitRent, stockService);
    }

    @Bean
    EncryptService encryptService() {
        return new EncryptServiceImpl(new BCryptPasswordEncoder());
    }

    @Bean
    AuthenticationService authenticationService(AuthenticationManager authenticationManager, JwtUtil jwtUtil,
                                                CustomUserDetailsServiceImpl customUserDetailsService){
        return new AuthenticationService(authenticationManager, jwtUtil, customUserDetailsService);
    }

    @Bean
    CategoryService categoryService(CategoryRepository categoryRepository) {
        return new CategoryService(categoryRepository);
    }

    @Bean
    BookService bookService(BookRepository bookRepository, CategoryService categoryService) {
        return new BookService(bookRepository, categoryService);
    }

    @Bean
    StockService stockService(StockRepository stockRepository, BookService bookService) {
        return new StockService(stockRepository, bookService);
    }

    @Bean
    ReserveService reserveService(ReserveRepository reserveRepository,
                                  UserService userService,
                                  BookService bookService,
                                  CustomUserDetailsService customUserDetailsService,
                                  StockService stockService
    ){
        return new ReserveService(reserveRepository, userService, bookService, customUserDetailsService, stockService);
    }

    @Bean
    RentReserveService rentReserveService(RentService rentService, ReserveService reserveService) {
        return new RentReserveService(rentService, reserveService);
    }
}
package com.irede.residence.domain.service;

import com.irede.residence.application.request.AuthenticationRequest;
import com.irede.residence.application.response.AuthenticationResponse;
import com.irede.residence.application.security.CustomUserDetailsServiceImpl;
import com.irede.residence.application.security.CustomUserDetails;
import com.irede.residence.infra.utils.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

public class AuthenticationService {

    private final AuthenticationManager authenticationManager;

    private final JwtUtil jwtUtil;

    private final CustomUserDetailsServiceImpl customUserDetailsServiceImp;


    public AuthenticationService(AuthenticationManager authenticationManager, JwtUtil jwtUtil,
                                 CustomUserDetailsServiceImpl customUserDetailsServiceImp) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.customUserDetailsServiceImp = customUserDetailsServiceImp;
    }

    public AuthenticationResponse getAuthenticationResponse(
            AuthenticationRequest authenticationRequest){

        authUserOrThrowException(authenticationRequest);

        CustomUserDetails userDetails = customUserDetailsServiceImp
                .loadUserByUsername(authenticationRequest.getUsername());

        String token = jwtUtil.generateToken(userDetails);

        return AuthenticationResponse.builder()
                .userName(userDetails.getUsername())
                .id(userDetails.getUserid())
                .token(token)
                .role(userDetails.getRole())
                .build();
    }

    private void authUserOrThrowException(AuthenticationRequest authenticationRequest) {
        try {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                    authenticationRequest.getUsername(),
                    authenticationRequest.getPassword()
            );
            authenticationManager.authenticate(authenticationToken);
        } catch (BadCredentialsException | DisabledException e) {
            throw new BadCredentialsException("INVALID_CREDENTIALS", e);
        }
    }
}

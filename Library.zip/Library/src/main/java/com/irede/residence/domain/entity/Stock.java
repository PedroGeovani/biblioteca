package com.irede.residence.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "stocks")
@EqualsAndHashCode(callSuper = true)
public class Stock extends BaseEntity {

    @OneToOne
    private Book book;

    private Integer totalQuantity;
    private Integer availableQuantity;
}
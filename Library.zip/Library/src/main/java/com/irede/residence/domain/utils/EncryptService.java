package com.irede.residence.domain.utils;

import java.util.Date;

public interface EncryptService {

    String hashString(String strToHash);

    String encryptPassword(String password);

    Date hashExpiration();

    Boolean matches(String rawPassword, String encryptedPass);
}

package com.irede.residence.infra.repository;

import com.irede.residence.domain.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface SpringDataCategoryRepository extends JpaRepository<Category, UUID> {
    Optional<Category> findCategoryByName(String name);
}

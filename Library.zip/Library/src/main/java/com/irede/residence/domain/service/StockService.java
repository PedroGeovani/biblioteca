package com.irede.residence.domain.service;

import com.irede.residence.domain.entity.Book;
import com.irede.residence.domain.entity.BookStatus;
import com.irede.residence.domain.entity.Stock;
import com.irede.residence.domain.exceptions.DomainException;
import com.irede.residence.domain.exceptions.ErrorCode;
import com.irede.residence.domain.repository.StockRepository;
import com.irede.residence.domain.to.*;

import java.util.Optional;
import java.util.UUID;

import static java.lang.Math.abs;

public class StockService {

    private final StockRepository stockRepository;

    private final BookService bookService;

    public StockService(StockRepository stockRepository, BookService bookService) {
        this.stockRepository = stockRepository;
        this.bookService = bookService;
    }

    public PageTO<Stock> getAll(PaginationTO paginationTO) {
        return stockRepository.findAll(paginationTO);
    }

    private Optional<Stock> findStockByBookId(UUID id) throws DomainException {
        Book book = bookService.findById(id);
        return stockRepository.findStockByBookId(book.getId());
    }

    public Stock getStockIfExistsByBookId(UUID id) throws DomainException {
        return this.findStockByBookId(id).orElseThrow(() -> new DomainException(ErrorCode.STOCK_NOT_FOUND));
    }

    public Book updateAvailableQuantity(UUID bookID, int quantity) throws DomainException {

        Optional<Stock> stock = this.findStockByBookId(bookID);

        if (stock.isEmpty()) {
            throw new DomainException(ErrorCode.STOCK_NOT_FOUND);
        }

        validateBookSituation(stock.get(), quantity);
        stockRepository.save(stock.get());
        return stock.get().getBook();
    }

    public Stock addBookToStock(StockTO stockTO) throws DomainException {

        Optional<Stock> stockDB = this.findStockByBookId(stockTO.getBookID());

        if (stockDB.isPresent()) {
            throw new DomainException(ErrorCode.BOOK_ALREADY_ON_STOCK);
        }

        Book book = bookService.findById(stockTO.getBookID());

        Stock stock = Stock.builder().book(book).totalQuantity(stockTO.getTotalQuantity()).availableQuantity(stockTO.getTotalQuantity()).build();

        return stockRepository.save(stock);
    }

    public Stock updateStockTotalQuantity(StockWithoutBookTO stockWithoutBookTO, UUID id) throws DomainException {

        Optional<Stock> stock = stockRepository.findById(id);

        if (stock.isEmpty()) {
            throw new DomainException(ErrorCode.STOCK_NOT_FOUND);
        }

        updateStockQuantity(stock.get(), stockWithoutBookTO.getTotalQuantity());
        return stockRepository.save(stock.get());
    }

    public void deleteStock(UUID id) throws DomainException {

        Optional<Stock> stock = stockRepository.findById(id);

        if (stock.isEmpty()) {
            throw new DomainException(ErrorCode.STOCK_NOT_FOUND);
        }

        stockRepository.delete(stock.get());
    }

    private void validateBookSituation(Stock stock, int quantity) throws DomainException {

        boolean quantityAvailable = stock.getAvailableQuantity() + quantity >= 0;

        if (!quantityAvailable) {
            throw new DomainException("You are trying to remove more books than available.", ErrorCode.DISALLOWED_AMOUNT);
        }

        int stockAvailableQuantity = stock.getAvailableQuantity() + quantity;
        stock.setAvailableQuantity(stockAvailableQuantity);

        updateStockStatus(stock, stockAvailableQuantity);
    }

    private void updateStockQuantity(Stock stock, int newQuantity) throws DomainException {

        int quantityDifference = newQuantity - stock.getTotalQuantity();

        if (stock.getAvailableQuantity() + quantityDifference < 0) {
            throw new DomainException("This will result in an available quantity less than 0.", ErrorCode.DISALLOWED_AMOUNT);
        }

        int stockAvailableQuantity = stock.getAvailableQuantity() + quantityDifference;

        updateStockStatus(stock, stockAvailableQuantity);

        stock.setTotalQuantity(newQuantity);
        stock.setAvailableQuantity(stockAvailableQuantity);
    }

    private void updateStockStatus(Stock stock, int availableQuantity) {
        if (availableQuantity == 0) {
            stock.getBook().setStatus(BookStatus.UNAVAILABLE);
        } else {
            stock.getBook().setStatus(BookStatus.AVAILABLE);
        }
    }
}
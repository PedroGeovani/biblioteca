#!/bin/bash

mvn clean install
# generate OWASP reports
# actual SonarQube analysis
mvn verify sonar:sonar \
  -Dsonar.projectKey=residence \
  -Dsonar.login=3c69076313921503694ff26422b4e76f3a9466ed